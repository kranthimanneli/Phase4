let quiz=[
    {
        question:"What is the HTML tag under which one can write the JavaScript code ?",
        option:[
            "<javascript>",
            "<scripted",
            "<script>",
            "js",
        ],
        answer:3,
    },
    {
        question:" Select a String function that creates a string and display in a big font as if it were in a tag ?",
        option:[
            "italics()",
            "big()",
            "anchor()",
            "blink()",
            
        ],
        answer:2,
    },
    {
        question:"Which of the following function of String object returns the capitalized string while respecting the current locale ?",
        option:[
            "toLocaleUpperCase()",
            "toUpperCase()",
            "toString()",
            "substring()",   
        ],
        answer:1,
    },
    {
        question:"Which of the following statements is valid for the features of JavaScript?",
        option:[
            "All",
            "JavaScript is complementary to and integrated with Java",
            "JavaScript is designed for creating network-centric applications",
            "JavaScript is a lightweight, interpreted programming language",   
        ],
        answer:1,

    },
    {
        question:"What is the function of Array object that adds and/or removes elements from an array ?",
        option:[
            "unshift()",
            "toSource",
            "sort()",
            "splice()",   
        ],
        answer:4,
    },
    {
        question:" Select a String function that finds the match between a regular expression and a string, and to replace the matched substring with a new substring ?",
        option:[
            "search()",
            "replace()",
            "match()",
            "concat()",   
        ],
        answer:2,
    },
    {
        question:"Which of the following methods removes the last element from an array and returns that element ?",
        option:[
            "NONE",
            "last()",
            "get()",
            "pop()",   
        ],
        answer:4,
    },
    {
        question:"Which of the following will return the type of the arguments passed to a function ?",
        option:[
            "using getType function",
            "using typeof operator",
            "Both of the above",
            "None",   
        ],
        answer:2,
    },
    {
        question:"Which of the following is a true statement for JavaScript callbacks?",
        option:[
            "A callback is a plain JavaScript function passed to some method as an argument or option",
            "Some callbacks are just events, called to give the user a chance to react when a certain state is triggered.",
            "None",
            "All except None",   
        ],
        answer:4,
    },
    {
        question:"Which of the following is the output of the below JavaScript codevar x = [typeof x, typeof y][1];typeof typeof x;",
        option:[
            "string",
            "undefined",
            "object",
            "number",   
        ],
        answer:1,
    }
]